The code is released under the GNU General Public License.
_________

This is a IMU Library for any WC (Wonder construct).

It can also be used with Arduino, ESP32, simply copy the folder to your library folder.
